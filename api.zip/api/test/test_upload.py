import io
import unittest

class TestAPI(unittest.TestCase):
	def test_upload_valid_image(test_client):
		image = "xmas.jpg"
		data = {
			'image': (open(image, 'rb'), image)
		}
		response = test_client.post('/', data=data)		
		assert response.status_code == 200
		
	def test_upload_invalid_image(test_client):
		file = "testing.txt"
		data = {
			'image': (open(file, 'rb'), file)
		}		
		response = test_client.post('/', data=data)		
		assert response.status_code == 400
	
	
if __name__ == '__main__':
	unittest.main()
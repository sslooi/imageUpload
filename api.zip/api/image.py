from flask import Flask, render_template
import logging, os
from flask import request

IMAGE_FOLDER = os.path.join('static', 'uploads')

app = Flask(__name__)
app.config['IMAGE_FOLDER'] = IMAGE_FOLDER
file_handler = logging.FileHandler('server.log')
app.logger.addHandler(file_handler)
app.logger.setLevel(logging.INFO)

@app.route('/')
def home():
	
	full_filename = os.path.join(app.config['IMAGE_FOLDER'], request.args.get('image'))
	return render_template('index.html',user_image = full_filename)
if __name__ == '__main__':
    app.run(debug=True)
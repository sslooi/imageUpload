from flask import Flask, request
from flask import abort
from flask import jsonify
import logging, os
import uuid
import imghdr
import shutil



app = Flask(__name__)
file_handler = logging.FileHandler('server.log')
app.logger.addHandler(file_handler)
app.logger.setLevel(logging.INFO)

PROJECT_HOME = os.path.dirname(os.path.realpath(__file__))

UPLOAD_FOLDER = '{}/uploads/'.format(PROJECT_HOME)
STATIC_FOLDER = '{}/static/uploads/'.format(PROJECT_HOME)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

	
def create_new_folder(local_dir):
    newpath = local_dir
    if not os.path.exists(newpath):
        os.makedirs(newpath)
    return newpath

def validate_image(path):
	return imghdr.what(path) != None
		

@app.route('/', methods = ['POST'])
def api_root():
	app.logger.info(PROJECT_HOME)
	if request.method == 'POST' and request.files['image']:		
		file = request.files['image']		
		file_name = str(uuid.uuid4())
		create_new_folder(app.config['UPLOAD_FOLDER'])
		saved_path = os.path.join(app.config['UPLOAD_FOLDER'], file_name)
		app.logger.info("saving {}".format(saved_path))
		file.save(saved_path)
		app.logger.info(imghdr.what(saved_path))
		if validate_image(saved_path) == False:
			return abort(400, 'Invalid file format')
		else:
			shutil.move( saved_path, STATIC_FOLDER)
			return jsonify(image=file_name)
    
	else:
		return abort(400, 'Please upload a file')

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)